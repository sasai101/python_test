from distutils.core import setup

setup(name="saiyin", version="1.0", description="saiyin'sModule", author="saiyin", py_modules=['TestMsg.sendmsg','TestMsg.recvmsg'])
